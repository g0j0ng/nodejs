//익스프레스 모듈
const { setInternalBufferSize } = require('bson');
const express = require('express');
const app = express();

//몽고db모듈
const MongoClient = require('mongodb').MongoClient;

//body-parser모듈
app.use(express.json());
app.use(express.urlencoded({extended:true}));


let scheduleDB;
MongoClient.connect('mongodb+srv://admin:qwer1234@cluster0.9bwcx.mongodb.net/schedule?retryWrites=true&w=majority',(err,client)=>{
  if(err) return console.log('db오류');
  scheduleDB=client.db('schedule');  
  app.listen(8080,()=>{
    console.log('8080포트 서버 오픈');
  })
})



app.get('/',(req,res)=>{
  console.log(req);
  res.sendFile(__dirname + '/index.html');
})

app.get('/write',(req,res)=>{
  console.log(req);
  res.sendFile(__dirname + '/write.html');
})


app.post('/add',(req,res)=>{
  scheduleDB.collection('today').insertOne(
    {
      title:req.body.title,
      order:req.body.order
    },(err,result)=>{
    if(err) return console.log('오류입니다.');
    res.sendFile(__dirname + '/index.html');
  });  
})