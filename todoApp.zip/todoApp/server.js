// express 서버
const express = require('express');
const app = express();
// body-parser
app.use(express.urlencoded({extended:true}));
app.use(express.json());

//mongoDB
const MongoClient = require('mongodb').MongoClient;

// EJS
app.set('view engine','ejs');
// 앱에 전처리 번역기로 ejs를 사용하겠다.



// 데이터베이스 접근
let todoAppDBUrl='mongodb+srv://admin:qwer1234@cluster0.9bwcx.mongodb.net/todoappDB?retryWrites=true&w=majority';
let todoAppDB;
MongoClient.connect(todoAppDBUrl,(err,result)=>{
  if(err) return console.log('db접근 오류');  
  todoAppDB=result.db('todoappDB');  
  
  //서버오픈
  app.listen(8080,()=>{
    console.log('8080포트가 열렸습니다.');
  })
});



// '/'로 접속시 시작페이지를 보내주자
// app.get('/',(req,res)=>{
//   res.sendFile(__dirname + '/index.html')
//   // console.log('응답완료');
// })

// '/write'로 접속시 write.html 보내주자
app.get('/write',(req,res)=>{
  res.sendFile(__dirname + '/write.html')
})

// '/delete'로 접속시 delete.html 보내주자
app.get('/delete',(req,res)=>{
  res.sendFile(__dirname + '/delete.html')
})

// '/update'로 접속시 update.html 보내주자
app.get('/update',(req,res)=>{
  res.sendFile(__dirname + '/update.html')
})

//app으로부터 넘어오는 POST 자료를 받아서 접속된 DB의 컬랙션에 기록하자
app.post('/add',(req,res)=>{
  let appTitle = req.body.title;
  let appOrder = Number(req.body.order);  
  // 발행자료 갯수
  todoAppDB.collection('postcount').findOne({개시물갯수:'개시물갯수'},(err,result)=>{
    if(err) return console.log('개시물갯수검색 실패');    
    let totalCount = result.전체갯수;
    //todoapp 자료저장
    todoAppDB.collection('todoapp').insertOne({title:appTitle,order:appOrder,_id:totalCount+1},(err,result)=>{
      if(err) return console.log('/add 오류');
      console.log('/add 성공');
      todoAppDB.collection('postcount').updateOne({개시물갯수:'개시물갯수'},{$inc:{전체갯수:1}},(err,result)=>{
        if(err) return console.log('/add 문서갯수 변경오류');
      })
    })
  });
  res.redirect('/write');
})


// /로 접근하는 앱에게 db자료전체를 찾아서 index.ejs에게 제공하자
// let findResult;
app.get('/',(req,res)=>{
  todoAppDB.collection('todoapp').find().toArray((err,result)=>{
    if(err)  return console.log('자료검색 오류');
    res.render('index.ejs',{todoData:result});    
  });
  // res.render('index.ejs',{todoData:findResult});
    //render가 오류없이 실행되려면 반드시 views폴더에 ejs파일이 위치해야함.
})